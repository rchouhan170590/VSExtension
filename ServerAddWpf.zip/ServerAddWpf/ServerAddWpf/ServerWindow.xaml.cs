﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.VisualStudio.Utilities;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
//using System.Windows.Forms;

//using System.Windows.Forms.Integration;

namespace ServerAddWpf
{
    /// <summary>
    /// Interaction logic for ServerWindow.xaml
    /// </summary>
    /// 
    public partial class ServerWindow : Window
    {
        public ServerWindow()
        {
            InitializeComponent();

            const int snugContentWidth = 380;
            const int snugContentHeight = 500;

            var horizontalBorderHeight = SystemParameters.ResizeFrameHorizontalBorderHeight;
            var verticalBorderWidth = SystemParameters.ResizeFrameVerticalBorderWidth;
            var captionHeight = SystemParameters.CaptionHeight;

            Width = snugContentWidth + 2 * verticalBorderWidth;
            Height = snugContentHeight + captionHeight + 2 * horizontalBorderHeight;

            initializeRadioBtn();

            Application.Current.MainWindow.Closing += new CancelEventHandler(MainWindow_Closed);
        }

        

       public void MainWindow_Closed(object sender, CancelEventArgs e)
       {
            Properties.Settings.Default.activeFileName = "-1";
            Properties.Settings.Default.Save();
            MessageBox.Show(Properties.Settings.Default.activeFileName);
        }

       private void select_server_file_btn_Click(object sender, RoutedEventArgs e)
       {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = false;
            Nullable<bool> dialogOk = fileDialog.ShowDialog();
            if(dialogOk == true)
            {
                server_file_textbox.Text = fileDialog.FileName;
            }

       }

        private void add_server_toSettingsbtn_Click(object sender, RoutedEventArgs e)
        {
            int serverCountvalue = Properties.Settings.Default.ServerCount;
            if(serverCountvalue == 10)
            {
                MessageBox.Show("Sorry, Max Limit Cross Cant Add More");
                return;
            }
            String file_path = server_file_textbox.Text.Trim();
            String displayName = serverDispalyNameText.Text.Trim();

            if(find_dispaly_name_index(displayName) != -1)
            {
                MessageBox.Show("Sorry, This Display Name already Used");
                return;
            }

            if (File.Exists(file_path))
            {
                if(displayName != null)
                {
                    System.Windows.Controls.RadioButton newBtn = new System.Windows.Controls.RadioButton();
                    String setValue = file_path + "####" + displayName;
                    newBtn.Content = displayName;
                    
                    serverFileStackPanel.Children.Add(newBtn);
                    
                    int emptyIndex = first_empty_rowSetting();
                    Properties.Settings.Default["configServer" + emptyIndex.ToString()] = setValue;
                    Properties.Settings.Default.Save();
                    
                    server_file_textbox.Text = "";
                    serverDispalyNameText.Text = "";

                    MessageBox.Show("New Server File Info Added");
                    return;
                }
                else
                {
                    MessageBox.Show("Please Enter The Display Name");
                }
            }
            else
            {
                MessageBox.Show("Please Select The File Path");
            }
            
            
        }

        public int find_dispaly_name_index(String name)
        {
            
            for(int i=1;i<=10;i++)
            {
                String propertyName = "configServer" + i.ToString();
                String settingFileValue = Properties.Settings.Default[propertyName].ToString();
                if(!settingFileValue.Equals("-1"))
                {
                    string toBeSearched = "####";
                    string code = settingFileValue.Substring(settingFileValue.IndexOf(toBeSearched) + toBeSearched.Length);
                    if(code.Equals(name))
                        return i;
                }
            }
            return -1;
        }

        public int first_empty_rowSetting()
        {
            for(int i=1;i<=10;i++)
            {
                String propertyName = "configServer" + i.ToString();
                String settingFileValue = Properties.Settings.Default[propertyName].ToString();
                if (settingFileValue.Equals("-1"))
                    return i;
            }
            return -1;
        }

        private void okaybtn_Click(object sender, RoutedEventArgs e)
        {
            ServerConfig x = new ServerConfig();
            String CurrentWorkingFile = Properties.Settings.Default.activeFileName;
            if (CurrentWorkingFile.Equals("-1"))
                CurrentWorkingFile = "No Active File";
            /*
            String checkRadioBtnName = "";
            foreach (object child in serverFileStackPanel.Children)
            {
                if (child is RadioButton)
                {
                    if ((bool)(child as RadioButton).IsChecked)
                    {
                        checkRadioBtnName = (child as RadioButton).Content.ToString();
                        break;
                    }
                }
            }
            */
            var checkedValue = serverFileStackPanel.Children.OfType<RadioButton>()
                 .FirstOrDefault(r => r.IsChecked.HasValue && r.IsChecked.Value);
            
            String ServerInfoFile = "No Server File Select";
            if (checkedValue != null)
            {
                int indexSettingFile = find_dispaly_name_index(checkedValue.Content.ToString());
                String valueFromSetting = Properties.Settings.Default["configServer" + indexSettingFile.ToString()].ToString();

                int charLocation = valueFromSetting.IndexOf("####", StringComparison.Ordinal);
                ServerInfoFile = valueFromSetting.Substring(0, charLocation);
            }
            

            String message = "This Part Not Completed \n";
            message = message + "Working File: " + CurrentWorkingFile + "\n";
            message = message + "Server Info File: " + ServerInfoFile;
            MessageBox.Show(message);
            
        }

        public void initializeRadioBtn()
        {
            for(int i=1;i<=10;i++)
            {
                String propertyName = "configServer" + i.ToString();
                String settingFileValue = Properties.Settings.Default[propertyName].ToString();
                if (!settingFileValue.Equals("-1"))
                {
                    string toBeSearched = "####";
                    string displayName = settingFileValue.Substring(settingFileValue.IndexOf(toBeSearched) + toBeSearched.Length);
                    
                    System.Windows.Controls.RadioButton newBtn = new System.Windows.Controls.RadioButton();
                    newBtn.Content = displayName;
                    serverFileStackPanel.Children.Add(newBtn);
                }
            }
        }

        private void deletebtn_Click(object sender, RoutedEventArgs e)
        {
            String checkRadioBtnName = "";
            int checkRadioBtnIndex = 0;
            foreach (object child in serverFileStackPanel.Children)
            {
                if (child is RadioButton)
                {
                    if ((bool)(child as RadioButton).IsChecked)
                    {
                        checkRadioBtnName = (child as RadioButton).Content.ToString();
                        checkRadioBtnIndex += 1;
                        break;
                    }
                    else
                        checkRadioBtnIndex += 1;
                }
            }
            if(checkRadioBtnIndex == 0)
            {
                MessageBox.Show("Nothing is selected");
                return;
            }
            
            serverFileStackPanel.Children.RemoveAt(checkRadioBtnIndex-1);

            int indexSettingFile = find_dispaly_name_index(checkRadioBtnName);
            Properties.Settings.Default["configServer" + indexSettingFile.ToString()] = "-1";
            Properties.Settings.Default.Save();

            MessageBox.Show("Server Info File Deleted");
        }


        //////////////// get current active file ///////////
        ///
        /*
        public void temp()
        {
            ServerConfig x =  new ServerConfig();
            String a =  x.get_current_active_file();
        }
        /*
        private IServiceProvider ServiceProvider1
        {
            get
            {
                return this.package;
            }
        }
        private string GetActiveDocumentFilePath(IServiceProvider serviceProvider)
        {
            EnvDTE80.DTE2 applicationObject = serviceProvider.GetService(typeof(DTE)) as EnvDTE80.DTE2;
            return applicationObject.ActiveDocument.FullName;

        }
        */


    }
}
