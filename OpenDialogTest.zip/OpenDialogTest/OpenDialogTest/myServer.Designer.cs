﻿namespace OpenDialogTest
{
    partial class myServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.add_server_btn = new System.Windows.Forms.Button();
            this.textbox_readServer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.deleteServerbtn = new System.Windows.Forms.Button();
            this.okaybtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // add_server_btn
            // 
            this.add_server_btn.Location = new System.Drawing.Point(256, 29);
            this.add_server_btn.Name = "add_server_btn";
            this.add_server_btn.Size = new System.Drawing.Size(114, 22);
            this.add_server_btn.TabIndex = 0;
            this.add_server_btn.Text = "Add Server";
            this.add_server_btn.UseVisualStyleBackColor = true;
            this.add_server_btn.Click += new System.EventHandler(this.add_server_click);
            // 
            // textbox_readServer
            // 
            this.textbox_readServer.Location = new System.Drawing.Point(12, 29);
            this.textbox_readServer.Name = "textbox_readServer";
            this.textbox_readServer.Size = new System.Drawing.Size(227, 22);
            this.textbox_readServer.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter Server Name";
            // 
            // deleteServerbtn
            // 
            this.deleteServerbtn.Location = new System.Drawing.Point(214, 418);
            this.deleteServerbtn.Name = "deleteServerbtn";
            this.deleteServerbtn.Size = new System.Drawing.Size(75, 23);
            this.deleteServerbtn.TabIndex = 3;
            this.deleteServerbtn.Text = "Delete";
            this.deleteServerbtn.UseVisualStyleBackColor = true;
            this.deleteServerbtn.Click += new System.EventHandler(this.deleteServerbtn_Click);
            // 
            // okaybtn
            // 
            this.okaybtn.Location = new System.Drawing.Point(295, 418);
            this.okaybtn.Name = "okaybtn";
            this.okaybtn.Size = new System.Drawing.Size(75, 23);
            this.okaybtn.TabIndex = 4;
            this.okaybtn.Text = "Select";
            this.okaybtn.UseVisualStyleBackColor = true;
            this.okaybtn.Click += new System.EventHandler(this.okaybtn_Click);
            // 
            // myServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 453);
            this.Controls.Add(this.okaybtn);
            this.Controls.Add(this.deleteServerbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textbox_readServer);
            this.Controls.Add(this.add_server_btn);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "myServer";
            this.Text = "myServer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button add_server_btn;
        private System.Windows.Forms.TextBox textbox_readServer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button deleteServerbtn;
        private System.Windows.Forms.Button okaybtn;
    }
}