﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpenDialogTest
{
    public partial class myServer : Form
    {
        public myServer()
        {
            InitializeComponent();
            initializeServerInfo();
        }

        int A = 1;
        private void add_server_click(object sender, EventArgs e)
        {

            if(textbox_readServer.Text.Trim() != null)
                addRadio_button(textbox_readServer.Text.ToString());
            else 
              MessageBox.Show("Please Enter Server Name");

        }

        public System.Windows.Forms.RadioButton addRadio_button(String btntxt)
        {
            System.Windows.Forms.RadioButton btn = new System.Windows.Forms.RadioButton();
            this.Controls.Add(btn);
            btn.Text = btntxt;
            btn.Top = A * 50;
            btn.Left = 15;

            A = A + 1;
            return btn;
        }

        public void initializeServerInfo()
        {
            int x = 0;
            for(int i=1;i<=5;i++)
            {
                string settingName = "configFile" + i.ToString();
                string btnText = Properties.Settings.Default[settingName].ToString();
                System.Windows.Forms.RadioButton btn = new System.Windows.Forms.RadioButton();
                this.Controls.Add(btn);
                btn.Top = A * 50;
                btn.Left = 15;
                btn.Text = btnText;
                A = A + 1;

            }
        }

        private void okaybtn_Click(object sender, EventArgs e)
        {
            myServer.ActiveForm.Close();
        }

        private void deleteServerbtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Not Ready to use");
        }
    }
}
